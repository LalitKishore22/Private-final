
function isAlphanumeric(str) {
    return str.match(/^[a-zA-Z0-9]+$/) !== null;
}

function Login(){
    
    AmagiLoader.show();
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    if(username.length > 0 && password.length > 0){
        console.log("Reaced")
        if(isAlphanumeric(username)){

            localStorage.setItem("username", username);
            LoginApi(username, password)
            setTimeout(() => {
                AmagiLoader.hide();
                location.replace("./dashboard.html")
             }, 3000);
            
            // alert("Helo")
            

        }
        else{
            alert("Please Enter Proper Details")
        }
    }

}

async function LoginApi(username, password){

    
    const xmlreq = new XMLHttpRequest()

    xmlreq.onreadystatechange = function(){
        if (xmlreq.readyState == XMLHttpRequest.DONE) {
            alert(xmlreq.responseText);
        }
        else{
            alert(xmlreq.status)
        }
    }

    xmlreq.open("POST","https://rhssouat.chola.murugappa.com/auth/realms/Peoplestrong/protocol/openid-connect/token");
    xmlreq.setRequestHeader("Origin", "https://d2c-hl-credit-dev.chola.murugappa.com")
    xmlreq.setRequestHeader("Authorization", "Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ")
    xmlreq.setRequestHeader("X-Requested-With", "XMLHttpRequest")
    xmlreq.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
    
    xmlreq.setRequestHeader("Access-Control-Request-Method", "POST, OPTIONS")
    xmlreq.setRequestHeader("Accept", "/")
    xmlreq.setRequestHeader("Accept-Encoding", "gzip, deflate, br")
    xmlreq.setRequestHeader("Accept-Language", "en-US,en;q=0.9")
    xmlreq.setRequestHeader("Cookie", "BIGipServerUAT_RHSSO_POOL=!qmiowNlr7enoIAEXalF8PsoZgflbJsFtll1HQqBoTAD/+9Ptd4YVR5PezYtdOYZGREZfdyTwSa+D6ms=")

    json = {
        "client_id": "https://d2c-hl-credit-dev.chola.murugappa.com",
      "client_secret": "e3a06235-c41a-48e5-9e82-66e4c20c2f72",
      "username": "CF09957",
      "password": "Feb&2717",
      "grant_type": "password"
    }

    xmlreq.send(json)

      
    // const fetchReq =  fetch("https://rhssouat.chola.murugappa.com/auth/realms/Peoplestrong/protocol/openid-connect/token",{
    //     method: "POST",
    //     mode:"cors",
    //     credentials: 'include',
    //     headers:{
           
    //         "Origin":"https://d2c-hl-credit-dev.chola.murugappa.com",
    //         "Authorization": "Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ",
    //         "X-Requested-With":" XMLHttpRequest",
    //         "Content-Type" : "application/x-www-form-urlencoded",
    //         "Access-Control-Request-Method":"POST, OPTIONS",
    //         "Accept": "/",
    //         "Accept-Encoding": "gzip, deflate, br",
    //         "Accept-Language": "en-US,en;q=0.9",
            
            
    //         "access-control-allow-origin":"http://127.0.0.1:5500",
    //         "Connection": "keep-alive",
    //         "Host": "rhssouat.chola.murugappa.com",
    //         "Origin":" http://127.0.0.1:5500",
    //         "Referer": "http://127.0.0.1:5500/",
    //         "Sec-Fetch-Dest": "empty",
    //         "Sec-Fetch-Mode": "cors",
    //         "Sec-Fetch-Site": "cross-site",
    //         "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
    //         "Cookie": "BIGipServerUAT_RHSSO_POOL=!qmiowNlr7enoIAEXalF8PsoZgflbJsFtll1HQqBoTAD/+9Ptd4YVR5PezYtdOYZGREZfdyTwSa+D6ms="
    //     },
    //     body: json
    // })

    // await fetchReq.then((response) =>{
    //     console.log(response.status);
    //     console.log(response.body)
    // })
    // .catch(error =>{
    //         console.log(error)
    // })    

    
    // "Access-Control-Request-Headers":"Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization",
}