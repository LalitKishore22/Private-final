let get_url = "http://127.0.0.1:8000/getdetails?user_id=";
let url_post = "http://127.0.0.1:8000/insertdetails?created_user_id=";
let url_delete = "";
let url_put = "";

let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#Colbtn"); 
let listView = document.getElementById("dataList");
// let data = [
//   {'memberreference': '653494260', 'cd_based_offer': 159233.01486199576, 'cd_based_max_emi': 4999.9, 'cd_mob': 4, 'cd_multiplier': 1.2, 'cd_based_elig_emi': 5999.9, 'runOff_based_offer': 391200.0, 'runOff_based_multiplier': 0.6, 'runoff_based_product': 'AL', 'runoff_percentage': 45, 'plbl_sanction_amt': 1517123.0, 'plbl_balance': 1443179.0, 'al_sanction_amt': 652000.0, 'al_balance': 352290.0, 'hl_sanction_amt': 4000000.0, 'hl_balance': 4306409.0, 'Final_Eligibility': 391200.0, 'Final_Eligibility_Product': 'AL'},
//   {'memberreference': '653494261', 'cd_based_offer': 159233.01486199576, 'cd_based_max_emi': 4999.9, 'cd_mob': 4, 'cd_multiplier': 1.2, 'cd_based_elig_emi': 5999.9, 'runOff_based_offer': 391200.0, 'runOff_based_multiplier': 0.6, 'runoff_based_product': 'BL', 'runoff_percentage': 50, 'plbl_sanction_amt': 1517123.0, 'plbl_balance': 1443179.0, 'al_sanction_amt': 652000.0, 'al_balance': 352290.0, 'hl_sanction_amt': 4000000.0, 'hl_balance': 4306409.0, 'Final_Eligibility': 391200.0, 'Final_Eligibility_Product': 'BL'},
//   {'memberreference': '653494262', 'cd_based_offer': 159233.01486199576, 'cd_based_max_emi': 4999.9, 'cd_mob': 4, 'cd_multiplier': 1.2, 'cd_based_elig_emi': 5999.9, 'runOff_based_offer': 391200.0, 'runOff_based_multiplier': 0.6, 'runoff_based_product': 'CL', 'runoff_percentage': 65, 'plbl_sanction_amt': 1517123.0, 'plbl_balance': 1443179.0, 'al_sanction_amt': 652000.0, 'al_balance': 352290.0, 'hl_sanction_amt': 4000000.0, 'hl_balance': 4306409.0, 'Final_Eligibility': 391200.0, 'Final_Eligibility_Product': 'PL'}

// ];

let data = []

closeBtn.addEventListener("click", ()=>{
  sidebar.classList.toggle("open");
  menuBtnChange();//calling the function(optional)
});

searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
  sidebar.classList.toggle("open");
  menuBtnChange(); //calling the function(optional)
});



// following are the code to change sidebar button(optional)
function menuBtnChange() {
 if(sidebar.classList.contains("open")){  
   closeBtn.classList.replace("bx-chevrons-right", "bx-chevrons-left");//replacing the iocns class
 }else {
   closeBtn.classList.replace("bx-chevrons-left","bx-chevrons-right");//replacing the iocns class
 }
}


function DataCardCreation(){
  let initial = document.getElementById("nodata");

  if(data.length == 0){
    initial.style = "display : ;"
  }
  else{
    initial.style = "display: none";

    data.forEach((card) =>{
      console.log(card)
      const cardElement = `
      <div class="col-md-3 mb-3" onclick = DataClick(this) data-bs-toggle="modal" data-bs-target="#cardModal">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title" id="cardTitle">${card["json_response"].memberreference}</h5>

              <p class="card-text">${card["json_response"].Final_Eligibility_Product}</p>
              <button onclick = DataClickUpdate(this) class="btn btn-outline-secondary" type="button" title="edit" data-bs-toggle="modal" data-bs-target="#updateModal"> <i class="fa fa-edit"></i></button>
              <button class="btn btn-outline-danger" type="button" title="delete" data-bs-toggle="modal" data-bs-target="#deleteModal"> <i class="fa fa-trash"></i></button>
            </div>
          </div>
      </div>
      
      `;
      listView.innerHTML += cardElement;
    })
  }
} 

function DataClick(e){


  let number = e.getElementsByClassName("card-title")[0].innerText;
  let value = ""
  for(let i = 0; i < data.length; i++){
    let sampleData = data[i]
    
    if(sampleData["json_response"].memberreference == number){
      value = sampleData["json_response"]
      break;
    }
  }

  // Adding values to Modal

  $('.modal-title').html(value.memberreference);  
  $('.cd_based_offer').html(value.cd_based_offer);
  $('.cd_based_max_emi').html(value.cd_based_max_emi);
  $('.cd_mob').html(value.cd_mob);
  $('.cd_multiplier').html(value.cd_multiplier);
  $('.cd_based_elig_emi').html(value.cd_based_elig_emi);
  $('.runOff_based_offer').html(value.runOff_based_offer);
  $('.runOff_based_multiplier').html(value.runOff_based_multiplier);
  $('.runoff_based_product').html(value.runoff_based_product);
  $('.runoff_percentage').html(value.runoff_percentage);
  $('.plbl_sanction_amt').html(value.plbl_sanction_amt);
  $('.plbl_balance').html(value.plbl_balance);
  $('.al_sanction_amt').html(value.al_sanction_amt);
  $('.al_balance').html(value.al_balance);
  $('.hl_sanction_amt').html(value.hl_sanction_amt);
  $('.hl_balance').html(value.hl_balance);
  $('.Final_Eligibility').html(value.Final_Eligibility);
  $('.Final_Eligibility_Product').html(value.Final_Eligibility_Product);

}

function DataClickUpdate(e){
 
  let number = e.parentNode.getElementsByClassName("card-title")[0].innerText;
  let value = ""
  for (let i = 0; i < data.length; i++){
    let sampleData = data[i]
    if(sampleData["json_response"].memberreference == number){
      value = sampleData["json_response"]
      break;
    }
  }

  // Adding values to Modal

  $('.modal-title').html(value.memberreference);  
  
  $('#cd_based_offer').val(value.cd_based_offer);
  $('#cd_based_max_emi').val(value.cd_based_max_emi);
  $('#cd_mob').val(value.cd_mob);
  $('#cd_multiplier').val(value.cd_multiplier);
  $('#cd_based_elig_emi').val(value.cd_based_elig_emi);
  $('#runOff_based_offer').val(value.runOff_based_offer);
  $('#runOff_based_multiplier').val(value.runOff_based_multiplier);
  $('#runoff_based_product').val(value.runoff_based_product);
  $('#runoff_percentage').val(value.runoff_percentage);
  $('#plbl_sanction_amt').val(value.plbl_sanction_amt);
  $('#plbl_balance').val(value.plbl_balance);
  $('#al_sanction_amt').val(value.al_sanction_amt);
  $('#al_balance').val(value.al_balance);
  $('#hl_sanction_amt').val(value.hl_sanction_amt);
  $('#hl_balance').val(value.hl_balance);
  $('#Final_Eligibility').val(value.Final_Eligibility);
  $('#Final_Eligibility_Product').val(value.Final_Eligibility_Product);

}

function DataDelete(){
  console.log("Deleted");
  $("[data-bs-dismiss=modal]").trigger({ type: "click" });
}

function DataUpdate(){

  let cd_based_offer = document.getElementById("cd_based_offer").value;
  let cd_based_max_emi = document.getElementById("cd_based_max_emi").value;
  let cd_mob = document.getElementById("cd_mob").value;
  let cd_multiplier = document.getElementById("cd_multiplier").value;
  let cd_based_elig_emi = document.getElementById("cd_based_elig_emi").value;
  let runOff_based_offer = document.getElementById("runOff_based_offer").value;
  let runOff_based_multiplier = document.getElementById("runOff_based_multiplier").value;
  let runoff_based_product = document.getElementById("runoff_based_product").value;
  let runoff_percentage = document.getElementById("runoff_percentage").value;
  let plbl_sanction_amt = document.getElementById("plbl_sanction_amt").value;
  let plbl_balance = document.getElementById("plbl_balance").value;
  let al_sanction_amt = document.getElementById("al_sanction_amt").value;
  let al_balance = document.getElementById("al_balance").value;
  let hl_sanction_amt = document.getElementById("hl_sanction_amt").value;
  let hl_balance = document.getElementById("hl_balance").value;
  let Final_Eligibility = document.getElementById("Final_Eligibility").value;
  let Final_Eligibility_Product = document.getElementById("Final_Eligibility_Product").value;


  $("[data-bs-dismiss=modal]").trigger({ type: "click" });
}

function Get(){

  
  AmagiLoader.show();

  let name = localStorage.getItem("username")
  let request = new XMLHttpRequest()
  request.onload = function () {

    let value = JSON.parse(this.responseText)
    data = value["items"]

    setTimeout(() => {
        AmagiLoader.hide();
     }, 3000);
     console.log(data)
    DataCardCreation()
  }
  request.open('GET', get_url+name, true);
  request.send();
}

function PostData(){
  AmagiLoader.show();
  const fileInp = document.getElementById("fileInp");
  const files = fileInp.files[0];

  const formData = new FormData();
  formData.append("file", files);
  fetch(url_post+localStorage.getItem("username"), {
    method: "POST",
    body: formData,
  })
  .then((res)={
    
  })
  .catch((error) => {
    console.log(error)
  });

  setTimeout(() => {
    AmagiLoader.hide();
  }, 3000);
  Get();

}

function UpdateData(){
 
  let requestUpdate = new XMLHttpRequest();

  requestUpdate.open('PUT', url_put, true);
  requestUpdate.setRequestHeader('Content-type', 'application/json; charset=UTF-8');
  requestUpdate.send(data);
  requestUpdate.onload = function () {
      if (requestUpdate.status === 200) {
          alert("Data Moved successfully!");
          Get();
      }
  }
}

function DeleteData(){
  let requestDelete = new XMLHttpRequest();

  requestDelete.open('DELETE', url_delete, true);
  requestDelete.setRequestHeader('Content-type', 'application/json; charset=UTF-8');
  requestDelete.send(data);
  requestDelete.onload = function () {
      if (requestDelete.status === 200) {
          alert("Data Deleted successfully!");
          Get();
      }
  }
}