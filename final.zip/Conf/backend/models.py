from sqlalchemy import Column, Integer, String, Numeric, JSON, Date
from sqlalchemy.ext.declarative import declarative_base

# Defining a base class for declarative class definitions
Base = declarative_base()

# Defining the existing details table
class Data(Base):
    __tablename__ = 'details1'

    id = Column(Integer, primary_key=True, autoincrement=True)
    member_reference = Column(String(25), nullable=False, unique=True)
    dms_id = Column(String(25), nullable=False, unique=True)
    final_eligibility = Column(Numeric(10, 2), nullable=False)
    final_eligibility_product = Column(String(20))
    json_response = Column(JSON)
    created_userid = Column(String(20), nullable=False)
    created_date = Column(Date, nullable=False)
    last_updated_date = Column(Date, nullable=False)
