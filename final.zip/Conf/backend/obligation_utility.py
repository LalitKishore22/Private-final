from fractions import Fraction
import datetime
import numpy as np

OTHER_DUPE_KEYS = ['DateOpenedOrDisbursed','highcreditsanctionedamount']

CC_DUPE_KEYS = ['AccountType','DateOpenedOrDisbursed']

#DUPE_CC_LOANS = ['10','16','31','35','36','37']


#CD_LOAN_CODES = ['06']

def mob_calc(date1, date2):
	date1 = datetime.strptime(date1, '%d%m%Y')
	date2 = datetime.strptime(date2, '%d%m%Y')
	print(type(date1))
	print(type(date2))
	delta = 0
	mob = abs((date1.year - date2.year) * 12 + (date1.month - date2.month))
	if date2.day > 25 and mob > 0:
		delta = -1
	mob = mob + delta
	return mob


def cdemi_calc(tl):
	emi_dict = {}
	completed_mob = 0
	emi_dict["tenureCap"] = 0
	emi_dict["irrCap"] = 0
	emi_dict["emiCap"] = 0
	if len(str(tl["highcreditsanctionedamount"]))>0 and len(str(tl["currentbalance"]))>0:
		pos = np.float64(tl["currentbalance"])
		amtfin = np.float64(tl["highcreditsanctionedamount"])
		#mob = tl["mob_disb"]
		ro_ratio = 1 - (np.float64(pos)/np.float64(amtfin))
		ro_fract = Fraction(ro_ratio).limit_denominator(36)
		gross_ten = ro_fract.denominator
		if gross_ten<=4:
			gross_ten = 12
		else:
			if gross_ten<8:
				gross_ten = gross_ten*2
		emi_cap = amtfin/gross_ten
		emi_dict["tenureCap"] = gross_ten
		emi_dict["emiCap"] = emi_cap
	return emi_dict


def common_dedupe(account_list):
	filterd = defaultdict(list)
	for tl in account_list:
		if tl["AccountType"] in DUPE_CC_LOANS:
			key_val_tup  = tuple([(k,tl[k]) for k in sorted(tl) if k in CC_DUPE_KEYS])
		else:
			key_val_tup = tuple([(k,tl[k]) for k in sorted(tl) if k in OTHER_DUPE_KEYS])
		filterd[key_val_tup].append(tl)
	filtered_latest = fetch_latest(dict(filterd))
	return filtered_latest

