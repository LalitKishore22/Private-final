import re
import os
import PyPDF2




member_pat = r'MEMBER NAME:\s*[A-Z ]+'
acc_no_pat = r'ACCOUNT NUMBER:\s*[A-Z0-9 ]+'
acc_type_pat = r'TYPE:\s*[A-Z -]+'
ownership_pat = r'OWNERSHIP:\s*(?:Individual|Guarantor|Joint|Deceased)'
open_date = r'OPENED:\s*[0-9-]+'
reported_pat = r'REPORTED AND CERTIFIED:\s*[0-9-]+'
closed_pat = r'CLOSED:\s*[0-9-]+'
pay_start_date = r'PMT HIST START:\s*[0-9-]+'
pay_end_date = r'PMT HIST END:\s*[0-9-]+'
last_payment = r'LAST PAYMENT:\s*[0-9-]+'
sanctioned = r'SANCTIONED:\s*[0-9,]+|HIGH-CREDIT:\s*[0-9,]+'
balance = r'CURRENT BALANCE:\s*[0-9,]+'
emi_pat = r'EMI:\s*[0-9,]+'
payment_freq = r'PAYMENT FREQUENCY:\s*[A-Z ]+'
tenure = r'REPAYMENT TENURE:\s*[0-9,]+'
interest = r'INTEREST RATE:\s*[0-9.]+'
actual_payment = r'ACTUAL PAYMENT:\s*[0-9,]+'
score_pat = r'Score\s*[0-9-]{1,3}'

COL_MAP = {'MEMBER NAME':'reportingmembershortname','ACCOUNT NUMBER':'accountnumber',
'TYPE':'account_type','OWNERSHIP':'ownershipindicator_des',
'OPENED':'dateopeneddisbursed','PMT HIST START':'pay_hist_start_date',
'PMT HIST END':'pay_hist_end_date','LAST PAYMENT':'dateoflastpayment',
'SANCTIONED':'highcreditsanctionedamount','CURRENT BALANCE':'currentbalance',
'EMI':'emi_amt','REPAYMENT TENURE':'tenure','INTEREST RATE':'roi',
'PAYMENT FREQUENCY':'paymt_freq_des','ACTUAL PAYMENT':'actual_paymt_amt',
'CLOSED':'dateclosed',"REPORTED AND CERTIFIED":"datereported_trades"}

ACC_MAP = {'personalloan':'Personal Loan',
'shorttermpersonalloan':'Personal Loan',
'loantoprofessional':'Loan to Professional',
'microfinance-personalloan':'Microfinance - Personal Loan',
'p2ppersonalloan':'P2P Personal Loan',
'microfinance-businessloan':'Microfinance - Business Loan',
'businessloan-secured':'Business Loan - Secured',
'businessloan-general':'Business Loan - General',
'businessloan-prioritysector-smallbusiness':'Business Loan - Priority Sector - Small Business',
'businessloan-prioritysector-others':'Business Loan - Priority Sector - Others',
'businessloan-unsecured':'Business Loan - Unsecured',
'businessloan':'Business Loan - Unsecured',
'autoloan(personal)':'Auto Loan (Personal)',
'autoloan':'Auto Loan (Personal)',
'p2pautoloan':'P2P Auto Loan',
'usedcarloan':'Used Car Loan',
'commercialvehicleloan':'Commercial Vehicle Loan',
'housingloan':'Housing Loan',
'propertyloan':'Property Loan',
'microfinance-housingloan':'Microfinance - Housing Loan',
'creditcard':'Credit Card',
'securedcreditcard':'Secured Credit Card',
'corporatecreditcard':'Corporate Credit Card',
'kisancreditcard':'Kisan Credit Card',
'consumerloan':'Consumer Loan'}

OWNER_MAP = {'guarantor':'3', 'individual':'1', 'joint':'4'}

def norm_str(val_str):
	norm_str = val_str.lower()
	norm_str = norm_str.replace(" ","")
	return norm_str

def conv_date(date_str):
	d_list = date_str.split("-")
	if len(d_list)==3:
		new_date = d_list[-1]+"-"+d_list[1]+"-"+d_list[0]
	else:
		new_date= date_str
	return new_date

def get_match_det(acc_str,PAT):
	d = {}
	match_list = re.findall(PAT,acc_str,re.I)
	if len(match_list)>0:
		fields = match_list[0].split(":")

		if clean_str(fields[0])=='HIGH-CREDIT':
			d[COL_MAP["SANCTIONED"]] = clean_str(fields[1])
		elif clean_str(fields[0])=='TYPE':
			d[COL_MAP[clean_str(fields[0])]] = clean_str(fields[1]).replace("OPENED","")
		else:
			d[COL_MAP[clean_str(fields[0])]] = clean_str(fields[1])
	return d

def clean_str(match_str):
	cleaned_str = match_str.rstrip()
	cleaned_str = cleaned_str.lstrip()
	cleaned_str = cleaned_str.replace(",","")
	cleaned_str = cleaned_str.replace("\n","")
	return cleaned_str

def get_account_det(acc_str):
	acc = {}
	acc.update(get_match_det(acc_str,member_pat))
	acc.update(get_match_det(acc_str,acc_no_pat))
	acc.update(get_match_det(acc_str,acc_type_pat))
	acc.update(get_match_det(acc_str,ownership_pat))
	acc.update(get_match_det(acc_str,open_date))
	acc.update(get_match_det(acc_str,reported_pat))
	acc.update(get_match_det(acc_str,closed_pat))
	acc.update(get_match_det(acc_str,pay_start_date))
	acc.update(get_match_det(acc_str,pay_end_date))
	acc.update(get_match_det(acc_str,last_payment))
	acc.update(get_match_det(acc_str,sanctioned))
	acc.update(get_match_det(acc_str,balance))
	acc.update(get_match_det(acc_str,emi_pat))
	acc.update(get_match_det(acc_str,payment_freq))
	acc.update(get_match_det(acc_str,tenure))
	acc.update(get_match_det(acc_str,interest))
	acc.update(get_match_det(acc_str,actual_payment))
	return acc

def get_cibil_json(pdf_file_path):
	cibil_ = {}
	pdf_text = ''
	acc_list = []
	pdf_reader = PyPDF2.PdfReader(pdf_file_path)
	for i in range(len(pdf_reader.pages)):
	    page = pdf_reader.pages[i]
	    pdf_text += page.extract_text()
	score_match = re.findall(score_pat,pdf_text,re.I)
	acc_det_str = pdf_text.split("ACCOUNT(S):")[1].split("ENQUIRIES:")[0]
	for acc_seg in acc_det_str.split("ACCOUNT DATES AMOUNTS STATUS"):
		if 'MEMBER NAME' in acc_seg:
			acc_ = get_account_det(acc_seg)
			acc_list.append(acc_)
	cibil_["Account"] = account_conv(acc_list)
	if len(score_match)>0:
		cibil_["Score"] = clean_str(score_match[0].split()[1])
	
	#logic for getting member reference number
	for i in pdf_text.split('\n'):
		if 'DATE:' in i:
			member_reference_no = i.replace('MEMBER REFERENCE NUMBER: ','').replace('NUMBER:','').split('DATE:')[0]
			cibil_['member_reference_no'] = member_reference_no
			break
	# print('ITs extracted info from pdf',cibil_)
	return cibil_

def account_conv(acc_list):
	new_list = []
	for tl in acc_list:
		tl["account_type"] = ACC_MAP.get(norm_str(tl["account_type"]),"Others")
		tl["ownershipindicator"] = OWNER_MAP.get(norm_str(tl["ownershipindicator_des"]),'2')
		tl["dateopeneddisbursed"] = conv_date(tl.get("dateopeneddisbursed",""))
		tl["pay_hist_start_date"] = conv_date(tl.get("pay_hist_start_date",""))
		tl["datereported_trades"] = conv_date(tl.get("datereported_trades",""))
		tl["pay_hist_end_date"] = conv_date(tl.get("pay_hist_end_date",""))
		tl["dateoflastpayment"] = conv_date(tl.get("dateoflastpayment",""))
		tl["dateclosed"] = conv_date(tl.get("dateclosed",''))
		new_list.append(tl)
	return new_list


if __name__ == '__main__':
	folder_path = "./data/"
	file_list  = [folder_path+i for i in os.listdir(folder_path) if i=='sample1.pdf']
	for file_name in file_list:
		cibil_data = get_cibil_json(file_name)
		print(file_name)
		print(len(cibil_data["Account"]))