from datetime import date
import aiofiles
from click import File
from fastapi import FastAPI, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select, delete, update
from sqlalchemy import and_
from models import Data
from fastapi.middleware.cors import CORSMiddleware
from plcs_offer_preprocess import pdf_to_offer
import json
import os

# MySQL database configuration
DATABASE_URL = "mysql+aiomysql://root:Lalit%4022@localhost/chola"

# Create a SQLAlchemy engine
engine = create_async_engine(DATABASE_URL)

# Create a session factory
SessionLocal = sessionmaker(bind=engine, class_=AsyncSession)

#Directory to store the uploaded pdf files
UPLOAD_DIR="uploads"

#Checking if upload directory exists
os.makedirs(UPLOAD_DIR,exist_ok=True)

# FastAPI app instance
app = FastAPI()

origins = [
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Route to insert details into the database 
@app.post("/insertdetails")
async def create_item(created_user_id: str, file: UploadFile = File()):
    try:
        contents = await file.read()
        filename=file.filename
        async with aiofiles.open(file.filename, 'wb') as f:
            await f.write(contents)
        print(filename)
        
        json_response = pdf_to_offer("./" + file.filename) #Extracting the final offer details from pdf (return type: json format)
        json_response = json_response[0]
        dms_id="DMS" + json_response["Final_Eligibility_Product"]
        member_reference = json_response["memberreference"]
        final_eligibility = json_response["Final_Eligibility"]
        final_eligibility_product = json_response["Final_Eligibility_Product"]
        
        try:
            async with SessionLocal() as session:
            # Creating a new instance of the Data model with the input data
                new_record = Data(member_reference=member_reference, dms_id=dms_id, final_eligibility=final_eligibility, final_eligibility_product=final_eligibility_product, 
                                json_response=json_response, created_userid=created_user_id, created_date=date.today(), last_updated_date=date.today())
                
                session.add(new_record)   # Adding the new instance to the session
                await session.commit()
                return {"Message":"Data inserted successfully."}
        except Exception as e:
            print(e)
            await session.rollback()
        
    except Exception as e:
        # Rollback the transaction in case of any error
        # await session.rollback()
        print("Error in data insertion.", e)
        return {"Error": e.args[0]}
    
    finally:
        if os.path.exists(filename):
            os.remove(filename)


# Route to retrieve details from the database
@app.get("/getdetails")
async def get_records(user_id: str):
    # Create a database session
    try:
        async with SessionLocal() as session:
            # Query to get items based on condition from the database
            query = select(Data)
            query = query.where(Data.created_userid == user_id)
            items = await session.execute(query)
            items = items.scalars().all()
            return {"items": [{"id": item.id,
                            "Member Reference": item.member_reference,
                            "DMS_id": item.dms_id,
                            "Final Eligibility": item.final_eligibility,
                            "Final Eligibility Product": item.final_eligibility_product,
                            "JSON Response": item.json_response,
                            "Created_user_id": item.created_userid,
                            "Created_date": item.created_date,
                            "Last_updated_date": item.last_updated_date} for item in items]}
    except Exception as e:
        print("Error in data retrieval")
        return {"Error": e.args[0]}

#Route to update records in the database
@app.put('/updatedetails')
async def update_data(user_id: str, member_reference: str, data: dict):
    try:
        async with SessionLocal() as session:
            #query to update data using the user id
            query = update(Data).where(and_(Data.created_userid == user_id, Data.member_reference == member_reference)).values(**data)
            result = await session.execute(query)
            await session.commit()
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="Item not found")
            return {"message": "Record updated successfully."}
    except Exception as e:
        # Rollback the transaction in case of any error
        await session.rollback()
        print("Error in data Updation.")
        return {"Error": e.args[0]}
            


# Route to delete record from the database
@app.delete("/deleterecord")
async def delete_records(user_id: str, member_reference: str):
    try:
        async with SessionLocal() as session:
            query = delete(Data).where(and_(Data.created_userid == user_id, Data.member_reference == member_reference))
            result = await session.execute(query)
            deleted_count = result.rowcount
        
            await session.commit()
            return {"message": f"Deletion Successful. {deleted_count} record(s) deleted."}
        
    except Exception as e:
        # Rollback the transaction in case of any error
        await session.rollback()
        print("Error in data deletion")
        return {"Error": e.args[0]}