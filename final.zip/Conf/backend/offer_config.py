
from datetime import datetime
from datetime import date


PL_CODES = ['Personal Loan', 'Loan to Professional', 'Microfinance - Personal Loan', 'P2P Personal Loan', 'Microfinance - Business Loan',
            'Business Loan - Secured', 'Business Loan - General', 'Business Loan - Priority Sector - Small Business',
            'Business Loan - Priority Sector - Others', 'Business Loan - Unsecured']
AL_CODES = ['Auto Loan (Personal)','P2P Auto Loan','Used Car Loan','Commercial Vehicle Loan']
HL_CODES = ['Housing Loan','Property Loan','Microfinance - Housing Loan']
CC_CODES = ['Credit Card', 'Secured Credit Card', 'Corporate Credit Card', 'Kisan Credit Card']
CD_CODES = ['Consumer Loan']

SCRUB_TYPE = {'suit_filed_status':str, 'Credit_Facility_Status':str, 'Paymt_hst_01':str,'Paymt_hst_02':str,'Paymt_hst_03':str,
    'Paymt_hst_04':str,'Paymt_hst_05':str,'Paymt_hst_06':str,'Paymt_hst_07':str,'Paymt_hst_08':str,'Paymt_hst_09':str,
    'Paymt_hst_10':str,'Paymt_hst_11':str,'Paymt_hst_12':str,'Paymt_hst_13':str,'Paymt_hst_14':str,
    'Paymt_hst_15':str,'Paymt_hst_16':str,'Paymt_hst_17':str,'Paymt_hst_18':str}

dpd_last3 = ['Paymt_hst_01','Paymt_hst_02','Paymt_hst_03']

dpd_last3_6 = ['Paymt_hst_04','Paymt_hst_05','Paymt_hst_06']

dpd_last6 = dpd_last3 + dpd_last3_6

dpd_last9= dpd_last6+['Paymt_hst_07','Paymt_hst_08','Paymt_hst_09']

dpd_last6_12 = ['Paymt_hst_07','Paymt_hst_08','Paymt_hst_09','Paymt_hst_10','Paymt_hst_11','Paymt_hst_12']

dpd_last12  = dpd_last6 + dpd_last6_12

dpd_last12_18 =['Paymt_hst_13','Paymt_hst_14','Paymt_hst_15','Paymt_hst_16','Paymt_hst_17','Paymt_hst_18']

dpd_last18 = dpd_last12 + dpd_last12_18

dpd_last_36 =  dpd_last18 + ['Paymt_hst_19','Paymt_hst_20','Paymt_hst_21','Paymt_hst_22',
'Paymt_hst_23','Paymt_hst_24','Paymt_hst_25','Paymt_hst_26','Paymt_hst_27','Paymt_hst_28',
'Paymt_hst_29','Paymt_hst_30','Paymt_hst_31','Paymt_hst_32','Paymt_hst_33','Paymt_hst_34','Paymt_hst_35','Paymt_hst_36']

LABEL_DICT ={'STD':0,'SUB':90,'SMA':60,'DBT':365,'LSS':730,'ZZZ':0,'XXX':0,'000':0}


COLS_RENAME = {'memberreference':'MemberReference','accountnumber':'AccountNumber',
'account_type':'AccountType','actual_paymt_amt':'actual_paymt_amt',
'amountoverdue':'AmountOverdue','cash_limit':'cash_limit',
'credit_facility_status':'Credit_Facility_Status','credit_limit':'credit_limit',
'currentbalance':'CurrentBalance','dateclosed':'DateClosed','dateoflastpayment':'DateofLastPayment',
'dateopeneddisbursed':'DateOpenedDisbursed','emi_amt':'emi_amt',
'datereported_trades':'datereported_trades','trade_report_close_date':'trade_report_close_date',
'highcreditsanctionedamount':'HighCreditSanctionedAmount', 'ownershipindicator':'OwnershipIndicator',
'pay_hist_end_date':'pay_hist_end_date','pay_hist_start_date':'Pay_Hist_Start_Date',
'paymt_hst_01':'Paymt_hst_01','paymt_hst_02':'Paymt_hst_02','paymt_hst_03':'Paymt_hst_03',
'paymt_hst_04':'Paymt_hst_04','paymt_hst_05':'Paymt_hst_05','paymt_hst_06':'Paymt_hst_06',
'paymt_hst_07':'Paymt_hst_07','paymt_hst_08':'Paymt_hst_08',
'paymt_hst_09':'Paymt_hst_09','paymt_hst_10':'Paymt_hst_10',
'paymt_hst_11':'Paymt_hst_11','paymt_hst_12':'Paymt_hst_12','paymt_hst_13':'Paymt_hst_13',
'paymt_hst_14':'Paymt_hst_14','paymt_hst_15':'Paymt_hst_15','paymt_hst_16':'Paymt_hst_16',
'paymt_hst_17':'Paymt_hst_17','paymt_hst_18':'Paymt_hst_18','paymt_hst_19':'Paymt_hst_19',
'paymt_hst_20':'Paymt_hst_20','paymt_hst_21':'Paymt_hst_21','paymt_hst_22':'Paymt_hst_22',
'paymt_hst_23':'Paymt_hst_23','paymt_hst_24':'Paymt_hst_24','paymt_hst_25':'Paymt_hst_25',
'paymt_hst_26':'Paymt_hst_26','paymt_hst_27':'Paymt_hst_27','paymt_hst_28':'Paymt_hst_28',
'paymt_hst_29':'Paymt_hst_29','paymt_hst_30':'Paymt_hst_30','paymt_hst_31':'Paymt_hst_31',
'paymt_hst_32':'Paymt_hst_32','paymt_hst_33':'Paymt_hst_33','paymt_hst_34':'Paymt_hst_34',
'paymt_hst_35':'Paymt_hst_35','paymt_hst_36':'Paymt_hst_36','reportingmembershortname':'ReportingMemberShortName','roi':'ROI','settlement_amt':'settlement_amt','suit_filed_status':'suit_filed_status','tenure':'tenure',
'writeoff_amt_prin':'writeoff_amt_prin','writeoff_amt_tot':'writeoff_amt_tot'}

