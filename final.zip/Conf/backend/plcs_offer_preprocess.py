
import pandas as pd
import numpy as np
import json
from datetime import datetime
from datetime import date
# from time import strptime
from offer_utility import *
from offer_config import *
from obligation_utility import *
from cibil_pdf_conv import *

currentDate = datetime.datetime.now().strftime("%Y%m%d")

# Tenure is 36 months, ROI is 21%
PLCS_EMI = 3768

PLCS_OWNER = ['1', '1.0']

mul_df = pd.read_csv('./resources/mul_pos_lookup.csv', dtype={'posFrom':int,'posTo':int, 'scoreFrom':int, 'scoreTo':int, 'posMul':str,'posProd':str})
cd_mul_df = pd.read_csv('./resources/cd_mul_lookup.csv', dtype={'mobFrom':int, 'mobTo':int, 'scoreFrom':str, 'scoreTo':str,  'mul':str, 'posProd':str})

def clean_date(date_str):
    date_obj  = None  
    if str(date_str)!='nan' and str(date_str)[:2]!='00' and str(date_str)!= 'NaT':      
        if "-" in str(date_str):
            date_obj = datetime.datetime.strptime(str(date_str),"%Y-%m-%d")
        else:
            date_str = str(int(float(date_str))).zfill(8)
            if len(date_str)==8:
                date_obj = datetime.datetime.strptime(date_str,"%d%m%Y")
            else:
                print(date_str)
    return date_obj

def get_cd_emi_mul(prod,score,mob):

    mob = int(mob)
    score = str(score)
    mul = 0

    mulList = list(cd_mul_df[(cd_mul_df.posProd == prod) & ((cd_mul_df.mobFrom <= mob) & (mob < cd_mul_df.mobTo)) & ((cd_mul_df.scoreFrom <= score) & (score < cd_mul_df.scoreTo))]['mul'])
    if len(mulList)>0:
        mul = float(mulList[0])
    return mul


def plcs_rule2(unique_acc,score):
    loan_det_list = []
    offer = 0
    max_emi = 0
    no_mos = 0
    max_val_mob = 0
    mul =0
    elig_emi = 0
    mob_list = []
    emi_dict = {}
    #try:
    for tl in unique_acc.to_dict('records'):
        if (str(tl["account_type"]) in CD_CODES) and (str(tl["ownershipindicator"]) in PLCS_OWNER) and (len(str(tl["highcreditsanctionedamount"])) > 0):
            hca = np.float64(tl["highcreditsanctionedamount"])
            bal = np.float64(tl["currentbalance"])
            if (hca >= 10000 and bal >0):
                no_mos = mobdisb_calc_live(tl)
                # no_mos = tl["mob_disb"]
                if no_mos >=3:
                    #loan_d = LOAN_CONFIG['CD']
                    #emi_dict, rem_tenure_flag = cdemi_calc(tl, loan_d)
                    emi_dict = cdemi_calc(tl)
                    loan_det_list.append(emi_dict['emiCap'])
                    mob_list.append(no_mos)
    if len(loan_det_list)>0 and len(mob_list)>0:    
        max_emi = max(loan_det_list)
        #print("max_emi", max_emi)
        max_val_index = loan_det_list.index(max_emi)
        max_val_mob = mob_list[max_val_index]
        # print("max_val_mob", max_val_mob)
        # print("score", score)
        mul = get_cd_emi_mul('CD', score, max_val_mob)
        # print("mul",mul)
        elig_emi = mul * max_emi
        # print("elig_emi",elig_emi)
        offer = (elig_emi/PLCS_EMI)*100000
        # print("CD_Offer",offer)
    # except Exception as e:
    #     print('Exception : error at plcs offerrule2',e)
    return offer, max_emi, max_val_mob, mul, elig_emi

def get_run_offer(prod, hca_list, bal_list, score):
    
    score = int(score)
    offer = 0
    mul = 0
    runoff = 0
    
    # print(score,"score")

    sum_hca = np.sum(hca_list)
    # print('sum_hca',sum_hca)
    # print('bal',np.sum(bal_list))
    runoff_amt = sum_hca - np.sum(bal_list)
    # print("runoff_amt",runoff_amt)
    # try:
    if runoff_amt > 0 and sum_hca>0:
        runoff = int((runoff_amt / sum_hca) * 100)
        # print("run off",runoff)
        mulList = list(mul_df[(mul_df.posProd == prod) & ((mul_df.posFrom <= runoff) & (runoff < mul_df.posTo)) & ((mul_df.scoreFrom <= score) & (score < mul_df.scoreTo))]['posMul'])
        if len(mulList)>0:
            mul = float(mulList[0])
            offer = float(sum_hca) * mul
    return offer,mul, runoff ,sum_hca ,np.sum(bal_list)

def plcs_rule3(acc_details,score):
    pl_hca_list = [0]
    pl_bal_list = [0]
    al_hca_list = [0]
    al_bal_list = [0]
    hl_hca_list = [0]
    hl_bal_list = [0]
    cibilscore = 0

    final_offer = 0
    mul = 0
    no_mos = 0
    amt_and_bal = {}
    #try:
    for tl in acc_details.to_dict('records'):
        if (tl["account_type"] in HL_CODES + PL_CODES + AL_CODES) and str(tl["ownershipindicator"]) in PLCS_OWNER and\
         (len(str(tl["highcreditsanctionedamount"])) > 0) and (len(str(tl["currentbalance"])) > 0):
            mob_ = mobdisb_calc_live(tl)
            hca = np.float64(tl["highcreditsanctionedamount"])
            bal = np.float64(tl["currentbalance"])
            if bal >0 :
                if tl["account_type"] in PL_CODES and mob_ >= 9:
                    # print('pl_tradeline',tl)
                    pl_hca_list.append(hca)
                    pl_bal_list.append(bal)
                elif tl["account_type"] in AL_CODES and mob_ >= 12:
                    al_hca_list.append(hca)
                    al_bal_list.append(bal)
                    # print('al_tradeline',tl)
                elif tl["account_type"] in HL_CODES and mob_ >= 12:
                    hl_hca_list.append(hca)
                    hl_bal_list.append(bal)
                    # print('hl_tradeline',tl)
    #print(sum(pl_hca_list),sum(pl_bal_list),score)
    pl_offer,pl_mul,pl_runoff,plbl_amt,plbl_bal = get_run_offer('PLBL',pl_hca_list,pl_bal_list,score)
    #print(pl_offer,pl_mul)
    al_offer,al_mul,al_runoff,al_amt,al_bal = get_run_offer('AL',al_hca_list,al_bal_list,score)
    hl_offer,hl_mul,hl_runoff,hl_amt,hl_bal = get_run_offer('HL',hl_hca_list,hl_bal_list,score)

    amt_and_bal['plbl_amt'] = plbl_amt
    amt_and_bal['plbl_bal'] = plbl_bal
    amt_and_bal['al_amt'] = al_amt
    amt_and_bal['al_bal'] = al_bal
    amt_and_bal['hl_amt'] = hl_amt
    amt_and_bal['hl_bal'] = hl_bal

    if pl_offer >= 50000:
        final_offer = pl_offer
        mul = pl_mul
        offer_tl = 'PLBL'
        runoff_per = pl_runoff
    else:
        final_offer = max(al_offer,hl_offer)
        if final_offer == hl_offer:
            mul = hl_mul
            offer_tl = 'HL'
            runoff_per = hl_runoff
        else:
            mul = al_mul
            offer_tl = 'AL'
            runoff_per = al_runoff
    # except Exception as e:
    #     print('Exception : error at plcs offerrule3',e)
    # print('final_offer',final_offer)
    # print('mul',mul)
    # print('offer_tl',offer_tl)
    return final_offer, mul, offer_tl, runoff_per,amt_and_bal

def get_plcs_final_offer(acc_df, score,val):
    #plcs_offers = PLCS_DEFAULT
    plcs_offers = {}
    plcs_offers["memberreference"] = val
    #final_plcs_offer = 0
    #offer = 0
    #rule = ''
    #try:
        #acc_details = cibil_["acc_details"]
        #customerSegment = cibil_["customerSegment"]
        #pull_date = cibil_['pull_date']
        #cibil_score = cibil_['cibil_score']
        #if len(str(cibil_score))>0:
        #    score = float(cibil_score)
        #else:
        #    score = 0
        # score = 800
        #unique_acc = common_dedupe(acc_details, CC_DUPKEYS, OTHER_DUPKEYS)

    plcs_offers["cd_based_offer"], plcsOffer2_maxEmi, cdEmi_mob, mul, elig_emi = plcs_rule2(acc_df,score)
    plcs_offers["cd_based_max_emi"] = round(plcsOffer2_maxEmi,1)
    plcs_offers["cd_mob"] = cdEmi_mob
    plcs_offers["cd_multiplier"] = mul
    plcs_offers["cd_based_elig_emi"] = round(elig_emi,1)
    plcs_offers["runOff_based_offer"], plcsOffer3_Mul, prod, runoff_per,amt_and_bal = plcs_rule3(acc_df,score)
    plcs_offers["runOff_based_multiplier"] = plcsOffer3_Mul
    plcs_offers["runoff_based_product"] = prod
    plcs_offers["runoff_percentage"] = runoff_per

    plcs_offers['plbl_sanction_amt'] = amt_and_bal['plbl_amt']
    plcs_offers['plbl_balance'] = amt_and_bal['plbl_bal']
    plcs_offers['al_sanction_amt'] = amt_and_bal['al_amt']
    plcs_offers['al_balance'] = amt_and_bal['al_bal']
    plcs_offers['hl_sanction_amt'] = amt_and_bal['hl_amt']
    plcs_offers['hl_balance'] = amt_and_bal['hl_bal']

    # print(plcs_offers.shape)
    # print(plcs_offers["plcsOffer_cdEmi_maxEmi"].unique().tolist())
    # print(plcs_offers["plcsOffer_posRunoffALHLPL_Mul"].unique().tolist())
    # except Exception as e:
    #     print('Exception : error PLCS Offer main function',e)
    return plcs_offers


def pdf_to_offer(file_name):
    cibil_data = get_cibil_json(file_name)
    acc_df = pd.DataFrame(cibil_data["Account"])
    score = cibil_data["Score"]
    val = cibil_data["member_reference_no"]
    plcs_offers_list = get_plcs_final_offer(acc_df,score,val)
    # print('want',plcs_offers_list)
    offer_df = pd.DataFrame([plcs_offers_list])
    condition = offer_df['runOff_based_offer'] > offer_df['cd_based_offer']
    default_value = 'CD'

    offer_df["Final_Eligibility"] = offer_df[["cd_based_offer", "runOff_based_offer"]].max(axis=1)
    #offer_df['PLCS_Offer_Amount'] = np.floor(offer_df['PLCS_Offer_Amount_Org'] / 1000) * 1000
    offer_df["Final_Eligibility_Product"] = np.where(condition, offer_df['runoff_based_product'], default_value)

    offer_df.loc[offer_df['runOff_based_offer'] == 0, 'runoff_based_product'] = 'No Offer'
    offer_df.loc[offer_df['Final_Eligibility'] == 0, 'Final_Eligibility_Product'] = 'No Offer'
    # print(offer_df)
    return offer_df.to_dict('records')

# if __name__ == '__main__':
#     file_name = './data/CIR_App_Sanjeev Kumar.pdf'
#     offer_det = pdf_to_offer(file_name)
#     print(offer_det)
    
    