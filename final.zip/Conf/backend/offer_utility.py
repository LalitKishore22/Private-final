import re
import numpy as np
from datetime import datetime
from dateutil.rrule import rrule,MONTHLY
from obligation_utility import *
from dateutil.relativedelta import relativedelta

PLCS_OWNER = ['1', '1.0']

date_pattern = '^((0[1-9]|1[0-9]|2[0-9]|3[01])(0[1-9]|1[0-2])(20[0-9]{2}))|((0[1-9]|1[0-9]|2[0-9]|3[01])(0[1-9]|1[0-2])(20[0-9]{2}))$'

CHOLA_PLBL_CODES = ['PLTL', 'PLOD', 'DCPL', 'BLTL', 'BLOD']

def month_diff(d2, d1):
	if isinstance(d1, str) == True:
		d_1 = datetime.strptime(str(d1),"%d%m%Y")
	else:
		d_1 = d1
	if isinstance(d2, str) == True:
		d_2 = datetime.strptime(str(d2),"%d%m%Y")
	else:
		d_2 = d2
	return (d_1.year - d_2.year) * 12 + d_1.month - d_2.month

def get_age(cibil):
	if cibil.get("consumer_name"):
		consumer_name = cibil["consumer_name"]
	else:
		consumer_name = ''
	age = 30
	if len(consumer_name)>0:
		dob_ = consumer_name.get("dob",'')
		if len(dob_)>0:
			dob_obj = datetime.strptime(str(dob_),"%d%m%Y")
			age = diff_month(datetime.now(),dob_obj)/12
	return age

def get_dpd(dpd_str,month=12):
	dpd_array = np.array([])
	dpd_str = dpd_str.replace("NODATA", "")
	dpd_str = dpd_str.replace("null", "")
	dpd_str = dpd_str.replace("XXX", "000")
	if len(dpd_str) % 3 != 0:
		dpd_str = re.sub(date_pattern, '', dpd_str)
	dpd_list = list(map(''.join, zip(*[iter(dpd_str)]*3)))
	for i in dpd_list:
		if i in LABEL_DICT.keys():
			im = LABEL_DICT.get(i,0)
			dpd_array = np.append(dpd_array,im)
		else:
			dpd_array = np.append(dpd_array,np.float(i))
	return dpd_array[:month]

def chola_plbl_check(tl):
	chola_plbl_flag  = 0
	# print("reportingmembershortname",tl["reportingmembershortname"])
	# print("accountnumber",tl["accountnumber"])
	if "CHOLA INVST FIN" in tl["reportingmembershortname"] and tl["accountnumber"][:4] in CHOLA_PLBL_CODES:
		chola_plbl_flag = 1
	return chola_plbl_flag

def get_cibil_score(cibil):
	cibil_score = -1
	cibil_details = cibil
	if len(str(cibil_details))>0:
		cibil_score = np.float(cibil_details)
		# cibil_details.get("score",'')
		# if len(cibil_details)>0:
			# cibil_score = np.float(cibil_details["score"])
			# cibil_score = np.float(cibil_details)
	return cibil_score

def date_gen(end_date,start_date):
	date_diff = abs(month_diff(end_date,start_date))
	dates = np.array([(start_date+relativedelta(months=+i)).strftime('%m%Y') for i in range(0,date_diff+1)])
	return dates

def mobdisb_calc(tl):
	#read the condition
	mob_disb = 0
	report_date =''
	from datetime import datetime
	if len(str(tl["dateopeneddisbursed"]))>0 and str(tl["dateopeneddisbursed"]).lower() not in ['', 'nan', 'null','nat','0']:
		open_date = datetime.strptime(str(tl["dateopeneddisbursed"]).split()[0],"%Y-%m-%d")
		if len(str(tl["dateclosed"]))>0 and str(tl["dateclosed"]).lower() not in ['', 'nan', 'null','nat','0']:
			report_date = datetime.strptime(str(tl["dateclosed"]).split()[0],"%Y-%m-%d")
		elif len(str(tl["dateoflastpayment"]))>0 and str(tl["dateoflastpayment"]).lower() not in ['', 'nan', 'null','nat','0']:
			report_date = datetime.strptime(str(tl["dateoflastpayment"]).split()[0], "%Y-%m-%d")
		elif len(str(tl["pay_hist_start_date"])) >0 and str(tl["pay_hist_start_date"]).lower() not in ['', 'nan', 'null','nat','0']:
			report_date = datetime.strptime(str(tl["pay_hist_start_date"]).split()[0], "%Y-%m-%d")
		if type(report_date) is datetime:
		 	mob_disb = month_diff(open_date,report_date)
	return mob_disb

def mobdisb_calc_live(tl):
	#read the condition	
	mob_disb = 0
	report_date =''
	bal = 0
	from datetime import datetime
	if len(str(tl["dateopeneddisbursed"]))>=8 and len(str(tl["dateclosed"]))<8:
		#print(str(tl["dateopeneddisbursed"]))
		open_date = datetime.strptime(str(tl["dateopeneddisbursed"]).split()[0],"%Y-%m-%d")
		if len(str(tl["datereported_trades"])) > 0:
			report_date = datetime.strptime(str(tl["datereported_trades"]).split()[0],"%Y-%m-%d")
		elif len(str(tl["pay_hist_start_date"])) > 0:
			report_date = datetime.strptime(str(tl["pay_hist_start_date"]).split()[0],"%Y-%m-%d")			
		if type(report_date) is datetime:
			mob_disb = month_diff(open_date,report_date)
	return mob_disb

def get_emi(tl):
	emi_est = 0
	code = LOAN_CODES.get(tl["accountType"], None)
	# if tl['accountType'] in PL_LOANS:
	# 	sanc_amt = np.float(tl['highCreditSanctionAmt'])
	#
	# 	# print('sanc_amt',sanc_amt)
	# 	# emi_est = sanc_amt/RULE1_EMI
	# 	# print('here_____________')
	# elif tl['accountType'] in AL_NY:
	# 	sanc_amt = np.float(tl['highCreditSanctionAmt'])
		# emi_est = sanc_amt / AL_EMI
	try:
		if tl["accountType"] in OTHER_LOAN:
			sanc_amt = np.float(tl['highCreditSanctionAmt'])
			if sanc_amt>=1000000:
				code = LOAN_CODES.get("02")
				loan_d = LOAN_CONFIG[code]
				emi_est,tenure_p = hlemi_calc(tl,loan_d)
				emi_est = emi_est['emiCap']
			elif sanc_amt<1000000 and sanc_amt!=0:
				code = LOAN_CODES.get("05")
				loan_d = LOAN_CONFIG[code]
				emi_est,tenure_p = hlemi_calc(tl,loan_d)
				emi_est = emi_est['emiCap']
		else:
			if code:
				loan_d = LOAN_CONFIG[code]
				emi_est,tenure_p = hlemi_calc(tl,loan_d)
				emi_est = emi_est['emiCap']
	except:
		pass
	# print('emi_est____________',emi_est)
	return emi_est

def date_gen(end_date,start_date):
	date_diff = abs(month_diff(end_date,start_date))
	dates = np.array([(start_date+relativedelta(months=+i)).strftime('%m%Y') for i in range(0,date_diff+1)])
	return dates

def pad_date(d):
	d = str(d)
	return "0"*(8-len(d)) + d

def get_open_date(tl):
	open_date = datetime.strptime(str(tl["dateOpenedOrDisbursed"]),'%d%m%Y')
	#modified open date based on emi presentation
	if open_date.day>=15:
		open_date = open_date+relativedelta(months=+2)
	else:
		open_date = open_date+relativedelta(months=+1)
	return open_date


def get_emi_vector(ac,date_vec,cc_adj_fac_opt,jt_hl_wt_opt):
	emi_cap = max(ac["emiCap"],0)
	tl_vec = np.zeros([1,len(date_vec)])
	ac_date = date_gen(ac["closedDate"],ac["openDate"])
	indices = np.where(np.in1d(date_vec, ac_date))
	if ac['accountType'] in accounts_in_scope:
		if ac["ownershipIndicator"] == '04' or ac["ownershipIndicator"] == '4':
			# vals = np.ones([1,len(ac_date)])*(emi_cap*jt_hl_wt)
			vals = np.ones([1,len(ac_date)])*(emi_cap*jt_hl_wt_opt)
		elif ac["ownershipIndicator"] in ('02','03') or ac["ownershipIndicator"] in ('2','3'):
			vals = np.ones([1,len(ac_date)])*(emi_cap*0)
		elif ac["accountType"] in ['10','12']:
			# For Credit Card trades and overdraft, the emi is decremented by the CC_Adj_Factor every year
			vals = np.array([])
			for dates in ac_date:
				# vals = np.append(vals, 1/(1+cc_adj_fac)**(int(dates[-4:])-int(ac_date[0][-4:]))*emi_cap)
				vals = np.append(vals, 1/(1+cc_adj_fac_opt)**(int(dates[-4:])-int(ac_date[0][-4:]))*emi_cap)
			vals = vals[::-1]
		else:
			vals = np.ones([1,len(ac_date)])*emi_cap
	else:
		vals = np.ones([1,len(ac_date)])*0
	np.put(tl_vec,indices,vals)
	return tl_vec
